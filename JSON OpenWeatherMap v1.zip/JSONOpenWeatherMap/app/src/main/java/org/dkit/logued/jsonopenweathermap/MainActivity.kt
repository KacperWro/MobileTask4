package org.dkit.logued.jsonopenweathermap

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
//import androidx.test.internal.runner.junit4.statement.UiThreadStatement.runOnUiThread




private val apiKey =
    "5c4966e66dbbd2a842b9ac6349a80fb5" // enter your OpenWeatherMap API Key here (APPID)
private val location = "Dublin,ie"
private val urlString = "https://api.openweathermap.org/data/2.5/weather?q=$location&APPID=$apiKey"

// Use an Explicit (named Service) Intent to create service
private lateinit var serviceIntent: Intent
private lateinit var intentFilter: IntentFilter    // for BroadcastReceiver
private lateinit var resultJsonString: String

// References to TextViews are declared here so that their scope is throughout the whole file
// which means they can be accessed bt the BroadcastReceiver and the Activity classes.
private lateinit var displayText: TextView
private lateinit var textView2: TextView
private lateinit var textView3: TextView
private lateinit var textView4: TextView

// create BroadcastReceiver
private val intentReceiver: BroadcastReceiver = object : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        Log.d("JSON", "BroadcastReceiver ... in onReceive()")

        // extract the JSON String from the Intent extra
        resultJsonString = intent?.getStringExtra("jsonString")
            ?: throw IllegalStateException("JSON string is null")

        Log.d("JSON", "BroadcastReceiver ... in onReceive(), extracting JSON String from Intent")

        displayText.text = "Raw Unparsed JSON : \n" + resultJsonString;

        // Demonstration of Parsing the JSON String to access individual fields and objects
        // using the json.org parser (which is included as the standard Android JSON parsing library)
        // We need to put the parsing in a background thread (as a Runnable) , however, to update the UI TextViews ,
        // we cant directly access them as the code is not running in the UI thread, therefore,
        // we must post the TextView updates to the UI Thread (i.e to the MainHandler)


        object : Thread() {
            override fun run() {
                 Log.d("JSON","in run() parsing JSON")
                    try {

                        val jsonObj = JSONObject(resultJsonString)  // get the root object (contains all JSON)

                        val base: String = jsonObj.getString("base")

                        // Get a handler that can be used to post to the main thread
                        var mainHandler: Handler  = Handler(Looper.getMainLooper());
                        var myRunnable : Thread = object : Thread() {
                            override fun run() {
                                textView2.text = "Base : " + base
                            }
                        }
                        mainHandler.post(myRunnable);


                        val wind: JSONObject = jsonObj.getJSONObject("wind")
                        val windSpeed = wind.getDouble("speed")
                        mainHandler = Handler(Looper.getMainLooper());
                        myRunnable  = object : Thread() {
                            override fun run() {
                                textView3.text = "Wind speed: " + windSpeed.toString()
                            }
                        }
                        mainHandler.post(myRunnable);


                        val weatherArray: JSONArray = jsonObj.getJSONArray("weather")
                        val weatherObject: JSONObject =
                            weatherArray[0] as JSONObject // get the first weather object (at index position 0)
                        val weatherDescription: String = weatherObject.getString("description")

                        mainHandler = Handler(Looper.getMainLooper());
                        myRunnable  = object : Thread() {
                            override fun run() {
                                textView4.text = "Weather description: " + weatherDescription
                            }
                        }
                        mainHandler.post(myRunnable);

                        Log.d("JSON","end of run() parsing JSON")
                    } catch (e: InterruptedException) {
                        e.printStackTrace()
                    }
            }
        }.start()
    }
}


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        displayText = findViewById<TextView>(R.id.textView1) // cast to TextView

        textView2 = findViewById<TextView>(R.id.textView2) // cast to TextView
        textView3 = findViewById<TextView>(R.id.textView3) // cast to TextView
        textView4 = findViewById<TextView>(R.id.textView4) // cast to TextView


        val intentFilter = IntentFilter()
        intentFilter.addAction("JSON_RETRIEVED") //note the same action as broadcast by the Service
        registerReceiver(intentReceiver, intentFilter)

        startService(
            Intent(baseContext, ReadJSONService::class.java).putExtra(
                "urlString",
                urlString
            )
        )

    }
}
